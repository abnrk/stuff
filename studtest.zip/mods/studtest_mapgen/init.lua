-- studtest_mapgen/init.lua

minetest.register_biome({
    name = "grasslands",
    node_top = "studtest_parts:part_bright_green",
    depth_top = 1,
    node_filler = "studtest_parts:part_earth_orange",
    depth_filler = 3,
    y_max = 1000,
    y_min = 3,
    heat_point = 30,
    humidity_point = 30,
})

minetest.register_biome({
    name = "desert",
    node_top = "studtest_parts:part_light_yellowich_orange",
    depth_top = 1,
    node_filler = "studtest_parts:part_light_yellowich_orange",
    depth_filler = 3,
    y_max = 5,
    y_min = 3,
    heat_point = 50,
    humidity_point = 30,
})

minetest.register_alias("mapgen_stone","studtest_parts:part_grey")
minetest.register_alias("mapgen_water_source","studtest_parts:part_bright_blue")
minetest.register_alias("mapgen_lava_source","studtest_parts:part_bright_red")
minetest.register_alias("mapgen_dirt","studtest_parts:part_earth_orange")
minetest.register_alias("mapgen_dirt_with_grass","studtest_parts:part_bright_green")
minetest.register_alias("mapgen_sand","studtest_parts:part_light_yellowich_orange")
minetest.register_alias("mapgen_tree","studtest_parts:part_earth_orange")
minetest.register_alias("mapgen_leaves","studtest_parts:part_dark_green")
minetest.register_alias("mapgen_apple","studtest_parts:part_bright_red")
minetest.register_alias("mapgen_cobble","studtest_parts:part_dark_grey")