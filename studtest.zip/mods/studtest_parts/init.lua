-- studtest_parts/init.lua
colors = {
	-- X11, already part of Minetest.
	{
		id = "x11_aliceblue",
		name = "Alice Blue",
		color = "aliceblue"
	},
	{
		id = "x11_antiquewhite",
		name = "Antique White",
		color = "antiquewhite"
	},
	{
		id = "x11_aquamarine",
		name = "Aquamarine",
		color = "aquamarine"
	},
	{
		id = "x11_azure",
		name = "Azure",
		color = "azure"
	},
	{
		id = "x11_beige",
		name = "Beige",
		color = "beige"
	},
	{
		id = "x11_bisque",
		name = "Bisque",
		color = "bisque"
	},
	{
		id = "x11_black",
		name = "Black (X11)",
		color = "black"
	},
	{
		id = "x11_blanchedalmond",
		name = "Blanched Almond",
		color = "blanchedalmond"
	},
	{
		id = "x11_blue",
		name = "Blue",
		color = "blue"
	},
	{
		id = "x11_blueviolet",
		name = "Blue Violet",
		color = "blueviolet"
	},
	{
		id = "x11_brown",
		name = "Brown",
		color = "brown"
	},
	{
		id = "x11_burlywood",
		name = "Burlywood",
		color = "burlywood"
	},
	{
		id = "x11_cadetblue",
		name = "Cadet Blue",
		color = "cadetblue"
	},
	{
		id = "x11_chartreuse",
		name = "Chartreuse",
		color = "chartreuse"
	},
	{
		id = "x11_chocolate",
		name = "Chocolate",
		color = "chocolate"
	},
	{
		id = "x11_coral",
		name = "Coral",
		color = "coral"
	},
	{
		id = "x11_cornflowerblue",
		name = "Cornflower Blue",
		color = "cornflowerblue"
	},
	{
		id = "x11_cornsilk",
		name = "Cornsilk",
		color = "cornsilk"
	},
	{
		id = "x11_crimson",
		name = "Crimson",
		color = "crimson"
	},
	{
		id = "x11_cyan",
		name = "Cyan",
		color = "cyan"
	},
	{
		id = "x11_darkblue",
		name = "Dark Blue",
		color = "darkblue"
	},
	{
		id = "x11_darkcyan",
		name = "Dark Cyan",
		color = "darkcyan"
	},
	{
		id = "x11_darkgoldenrod",
		name = "Dark Goldenrod",
		color = "darkgoldenrod"
	},
	{
		id = "x11_darkgray",
		name = "Dark Gray",
		color = "darkgray"
	},
	{
		id = "x11_darkgreen",
		name = "Dark Green (X11)",
		color = "darkgreen"
	},
	{
		id = "x11_darkkhaki",
		name = "Dark Khaki",
		color = "darkkhaki"
	},
	{
		id = "x11_darkmagenta",
		name = "Dark Magenta",
		color = "darkmagenta"
	},
	{
		id = "x11_darkolivegreen",
		name = "Dark Olive Green",
		color = "darkolivegreen"
	},
	{
		id = "x11_darkorange",
		name = "Dark Orange (X11)",
		color = "darkorange"
	},
	{
		id = "x11_darkorchid",
		name = "Dark Orchid",
		color = "darkorchid"
	},
	{
		id = "x11_darkred",
		name = "Dark Red (X11)",
		color = "darkred"
	},
	{
		id = "x11_darksalmon",
		name = "Dark Salmon",
		color = "darksalmon"
	},
	{
		id = "x11_darkseagreen",
		name = "Dark Sea Green",
		color = "darkseagreen"
	},
	{
		id = "x11_darkslateblue",
		name = "Dark Slate Blue",
		color = "darkslateblue"
	},
	{
		id = "x11_darkslategray",
		name = "Dark Slate Gray",
		color = "darkslategray"
	},
	{
		id = "x11_darkturquoise",
		name = "Dark Turquoise",
		color = "darkturquoise"
	},
	{
		id = "x11_darkviolet",
		name = "Dark Violet",
		color = "darkviolet"
	},
	{
		id = "x11_deeppink",
		name = "Deep Pink",
		color = "deeppink"
	},
	{
		id = "x11_deepskyblue",
		name = "Deep Sky Blue",
		color = "deepskyblue"
	},
	{
		id = "x11_firebrick",
		name = "Fire Brick",
		color = "firebrick"
	},
	{
		id = "x11_floralwhite",
		name = "Floral White",
		color = "floralwhite"
	},
	{
		id = "x11_forestgreen",
		name = "Forest Green",
		color = "forestgreen"
	},
	{
		id = "x11_fuchsia",
		name = "Fuchsia",
		color = "fuchsia"
	},
	{
		id = "x11_gainsboro",
		name = "Gainsboro",
		color = "gainsboro"
	},
	{
		id = "x11_ghostwhite",
		name = "Ghost White",
		color = "ghostwhite"
	},
	{
		id = "x11_gold",
		name = "Gold",
		color = "gold"
	},
	{
		id = "x11_goldenrod",
		name = "Goldenrod",
		color = "goldenrod"
	},
	{
		id = "x11_gray",
		name = "Gray",
		color = "gray"
	},
	{
		id = "x11_honeydew",
		name = "Honeydew",
		color = "honeydew"
	},
	{
		id = "x11_hotpink",
		name = "Hot Pink",
		color = "hotpink"
	},
	{
		id = "x11_indianred",
		name = "Indian Red",
		color = "indianred"
	},
	{
		id = "x11_indigo",
		name = "Indigo",
		color = "indigo"
	},
	{
		id = "x11_ivory",
		name = "Ivory",
		color = "ivory"
	},
	{
		id = "x11_khaki",
		name = "Khaki",
		color = "khaki"
	},
	{
		id = "x11_lavender",
		name = "Lavender",
		color = "lavender"
	},
	{
		id = "x11_lavenderblush",
		name = "Lavender Blush",
		color = "lavenderblush"
	},
	{
		id = "x11_lawngreen",
		name = "Lawn Green",
		color = "lawngreen"
	},
	{
		id = "x11_lemonchiffon",
		name = "Lemon Chiffon",
		color = "lemonchiffon"
	},
	{
		id = "x11_lightblue",
		name = "Light Blue (X11)",
		color = "lightblue"
	},
	{
		id = "x11_lightcoral",
		name = "Light Coral",
		color = "lightcoral"
	},
	{
		id = "x11_lightcyan",
		name = "Light Cyan",
		color = "lightcyan"
	},
	{
		id = "x11_lightgoldenrodyellow",
		name = "Light Goldenrod Yellow",
		color = "lightgoldenrodyellow"
	},
	{
		id = "x11_lightgray",
		name = "Light Gray",
		color = "lightgray"
	},
	{
		id = "x11_lightgreen",
		name = "Light Green (X11)",
		color = "Light Green"
	},
	{
		id = "x11_lightpink",
		name = "Light Pink (X11)",
		color = "lightpink"
	},
	{
		id = "x11_lightsalmon",
		name = "Light Salmon",
		color = "lightsalmon"
	},
	{
		id = "x11_lightseagreen",
		name = "Light Sea Green",
		color = "lightseagreen"
	},
	{
		id = "x11_lightskyblue",
		name = "Light Sky Blue",
		color = "lightskyblue"
	},
	{
		id = "x11_lightyellow",
		name = "Light Yellow (X11)",
		color = "lightyellow"
	},
	{
		id = "x11_lime",
		name = "Lime",
		color = "lime"
	},
	{
		id = "x11_limegreen",
		name = "Lime Green",
		color = "limegreen"
	},
	{
		id = "x11_linen",
		name = "Linen",
		color = "linen"
	},
	{
		id = "x11_magenta",
		name = "Magenta",
		color = "magenta"
	},
	{
		id = "x11_maroon",
		name = "Maroon",
		color = "maroon"
	},
	{
		id = "x11_mediumaquamarine",
		name = "Medium Aquamarine",
		color = "mediumaquamarine"
	},
	{
		id = "x11_mediumblue",
		name = "Medium Blue (X11)",
		color = "mediumblue"
	},
	{
		id = "x11_mediumorchid",
		name = "Medium Orchid",
		color = "mediumorchid"
	},
	{
		id = "x11_mediumpurple",
		name = "Medium Purple",
		color = "mediumpurple"
	},
	{
		id = "x11_mediumseagreen",
		name = "Medium Sea Green",
		color = "mediumseagreen"
	},
	{
		id = "x11_mediumslateblue",
		name = "Medium Slate Blue",
		color = "mediumslateblue"
	},
	{
		id = "x11_mediumturquoise",
		name = "Medium Turquoise",
		color = "mediumturquoise"
	},
	{
		id = "x11_mediumvioletred",
		name = "Medium Violet Red",
		color = "mediumvioletred"
	},
	{
		id = "x11_midnightblue",
		name = "Midnight Blue",
		color = "midnightblue"
	},
	{
		id = "x11_mintcream",
		name = "Mint Cream",
		color = "mintcream"
	},
	{
		id = "x11_mistyrose",
		name = "Misty Rose",
		color = "mistyrose"
	},
	{
		id = "x11_moccasin",
		name = "Moccasin",
		color = "moccasin"
	},
	{
		id = "x11_navajowhite",
		name = "Navajo White",
		color = "navajowhite"
	},
	{
		id = "x11_navy",
		name = "Navy",
		color = "navy"
	},
	{
		id = "x11_oldlace",
		name = "Old Lace",
		color = "oldlace"
	},
	{
		id = "x11_olive",
		name = "Olive",
		color = "olive"
	},
	{
		id = "x11_olivedrab",
		name = "Olive Drab",
		color = "olivedrab"
	},
	{
		id = "x11_orange",
		name = "Orange",
		color = "orange"
	},
	{
		id = "x11_orangered",
		name = "Orange Red",
		color = "orangered"
	},
	{
		id = "x11_orchid",
		name = "Orchid",
		color = "orchid"
	},
	{
		id = "x11_palegoldrenrod",
		name = "Pale Goldenrod",
		color = "palegoldenrod"
	},
	{
		id = "x11_palegreen",
		name = "Pale Green",
		color = "palegreen"
	},
	{
		id = "x11_paleturquoise",
		name = "Pale Turquoise",
		color = "paleturquoise"
	},
	{
		id = "x11_palevioletred",
		name = "Pale Violet Red",
		color = "palevioletred"
	},
	{
		id = "x11_papayawhip",
		name = "Papaya Whip",
		color = "papayawhip"
	},
	{
		id = "x11_peachpuff",
		name = "Peach Puff",
		color = "peachpuff"
	},
	{
		id = "x11_peru",
		name = "Peru",
		color = "peru"
	},
	{
		id = "x11_pink",
		name = "Pink",
		color = "pink"
	},
	{
		id = "x11_plum",
		name = "Plum",
		color = "plum"
	},
	{
		id = "x11_powderblue",
		name = "Powder Blue",
		color = "powderblue"
	},
	{
		id = "x11_purple",
		name = "Purple",
		color = "purple"
	},
	{
		id = "x11_rebeccapurple",
		name = "Rebecca Purple",
		color = "rebeccapurple"
	},
	{
		id = "x11_red",
		name = "Red",
		color = "red"
	},
	{
		id = "x11_rosybrown",
		name = "Rosy Brown",
		color = "rosybrown"
	},
	{
		id = "x11_royalblue",
		name = "Royal Blue (X11)",
		color = "royalblue"
	},
	{
		id = "x11_saddlebrown",
		name = "Saddle Brown",
		color = "saddlebrown"
	},
	{
		id = "x11_salmon",
		name = "Salmon",
		color = "salmon"
	},
	{
		id = "x11_sandybrown",
		name = "Sandy Brown",
		color = "sandybrown"
	},
	{
		id = "x11_seagreen",
		name = "Sea Green",
		color = "seagreen"
	},
	{
		id = "x11_seashell",
		name = "Seashell",
		color = "seashell"
	},
	{
		id = "x11_sienna",
		name = "Sienna",
		color = "sienna"
	},
	{
		id = "x11_silver",
		name = "Silver (X11)",
		color = "silver"
	},
	{
		id = "x11_skyblue",
		name = "Sky Blue",
		color = "skyblue"
	},
	{
		id = "x11_slateblue",
		name = "Slate Blue",
		color = "slateblue"
	},
	{
		id = "x11_slategray",
		name = "Slate Gray",
		color = "slategray"
	},
	{
		id = "x11_snow",
		name = "Snow",
		color = "snow"
	},
	{
		id = "x11_springgreen",
		name = "Spring Green",
		color = "springgreen"
	},
	{
		id = "x11_steelblue",
		name = "Steel Blue",
		color = "steelblue"
	},
	{
		id = "x11_tan",
		name = "Tan",
		color = "tan"
	},
	{
		id = "x11_teal",
		name = "Teal",
		color = "teal"
	},
	{
		id = "x11_thistle",
		name = "Thistle",
		color = "thistle"
	},
	{
		id = "x11_tomato",
		name = "Tomato",
		color = "tomato"
	},
	{
		id = "x11_turquoise",
		name = "Turquoise",
		color = "turquoise"
	},
	{
		id = "x11_violet",
		name = "Violet",
		color = "violet"
	},
	{
		id = "x11_wheat",
		name = "Wheat",
		color = "wheat"
	},
	{
		id = "x11_white",
		name = "White (X11)",
		color = "white"
	},
	{
		id = "whitesmoke",
		name = "White Smoke",
		color = "whitesmoke"
	},
	{
		id = "x11_yellow",
		name = "Yellow",
		color = "yellow"
	},
	{
		id = "x11_yellowgreen",
		name = "Yellow Green",
		color = "yellowgreen"
	},
	-- Lego
	{
		id = "white",
		name = "White",
		color = "#f2f3f2"
	},
	{
		id = "grey",
		name = "Grey",
		color = "#a1a5a2"
	},
	{
		id = "light_yellow",
		name = "Light Yellow",
		color = "#f9e999"
	},
	{
		id = "brick_yellow",
		name = "Brick Yellow",
		color = "#d7c599"
	},
	{
		id = "light_green",
		name = "Light Green",
		color = "#c2dab8"
	},
	{
		id = "light_reddish_violet",
		name = "Light Reddish Violet",
		color = "#cb8442"
	},
	{
		id = "nougat",
		name = "Nougat",
		color = "#cc8e68"
	},
	{
		id = "bright_red",
		name = "Bright Red",
		color = "#c4281b"
	},
	{
		id = "bright_red",
		name = "Bright Red",
		color = "#c4281b"
	},
	{
		id = "medium_reddish_violet",
		name = "Medium Reddish Violet",
		color = "#c470a0"
	},
	{
		id = "bright_blue",
		name = "Bright Blue",
		color = "#0d69ab"
	},
	{
		id = "bright_yellow",
		name = "Bright Yellow",
		color = "#f5cd2f"
	},
	{
		-- What do you mean Earth Orange?
		id = "earth_orange",
		name = "Earth Orange",
		color = "#624732"
	},
	{
		id = "black",
		name = "Black",
		color = "#1b2a34"
	},
	{
		id = "dark_grey",
		name = "Dark Grey",
		color = "#6d6e6c"
	},
	{
		id = "dark_green",
		name = "Dark Green",
		color = "#287f46"
	},
	{
		-- Yellowich?
		id = "light_yellowich_orange",
		name = "Light Yellowich Orange",
		color = "#f3cf9b"
	},
	{
		id = "bright_green",
		name = "Bright Green",
		color = "#4b974a"
	},
	{
		id = "dark_orange",
		name = "Dark Orange",
		color = "#a05f34"
	},
	{
		id = "light_bluish_violet",
		name = "Light Bluish Violet",
		color = "#c1cade"
	},
	{
		id = "light_blue",
		name = "Light Blue",
		color = "#b4d2e3"
	},
	{
		id = "light_red",
		name = "Light Red",
		color = "#eec4b6"
	},
	{
		id = "medium_red",
		name = "Medium Red",
		color = "#da8679"
	},
	{
		id = "light_grey",
		name = "Light Grey",
		color = "#c7c1b7"
	},
	{
		id = "bright_violet",
		name = "Bright Violet",
		color = "#6b327b"
	},
	{
		id = "bright_violet",
		name = "Bright Violet",
		color = "#6b327b"
	},
	{
		id = "bright_yellowish_orange",
		name = "Bright Yellowish Orange",
		color = "#e29b3f"
	},
	{
		-- What do you mean Earth Yellow?
		id = "earth_yellow",
		name = "Earth Yellow",
		color = "#685c43"
	},
	{
		id = "bright_bluish_violet",
		name = "Bright Bluish Violet",
		color = "#435493"
	},
	{
		id = "medium_bluish_violet",
		name = "Medium Bluish Violet",
		color = "#6874ac"
	},
	{
		id = "medium_yellowish_green",
		name = "Medium Yellowish Green",
		color = "#6874ac"
	},
	{
		id = "medium_bluish_green",
		name = "Medium Bluish Green",
		color = "#55a5af"
	},
	{
		id = "light_bluish_green",
		name = "Light Bluish Green",
		color = "#b7d7d5"
	},
	{
		id = "bright_yellowish_green",
		name = "Bright Yellowish Green",
		color = "#a4bd46"
	},
	{
		id = "light_yellowish_green",
		name = "Light Yellowish Green",
		color = "#d9e4a7"
	},
	{
		id = "medium_yellowish_orange",
		name = "Medium Yellowish Orange",
		color = "#e7ac58"
	},
	{
		id = "bright_yellowish_orange",
		name = "Bright Yellowish Orange",
		color = "#d36f4c"
	},
	{
		id = "bright_reddish_violet",
		name = "Bright Reddish Violet",
		color = "#923978"
	},
	{
		id = "light_orange",
		name = "Light Orange",
		color = "#eab891"
	},
	{
		id = "gold",
		name = "Gold",
		color = "#dcbc81"
	},
	{
		id = "dark_nougat",
		name = "Dark Nougat",
		color = "#ae7a59"
	},
	{
		id = "silver",
		name = "Silver",
		color = "#9ca3a8"
	},
}

for _,color in ipairs(colors) do
		minetest.register_node("studtest_parts:part_"..color.id, {
		description = color.name.." Part",
		tiles = {
			{name="studtest_parts_outset.png", color=color.color},
			{name="studtest_parts_inset.png", color=color.color},
			{name="studtest_parts_smooth.png", color=color.color}
		},
		groups = {cracky = 1}
	})
end

minetest.register_alias("studtest_parts:med_reddish_violet","studtest_parts:medium_reddish_violet")
minetest.register_alias("studtest_parts:lig_yellowich_orange","studtest_parts:light_yellowich_orange")
minetest.register_alias("studtest_parts:lig_yellowish_orange","studtest_parts:light_yellowich_orange")
minetest.register_alias("studtest_parts:light_yellowish_orange","studtest_parts:light_yellowich_orange")