minetest.register_on_joinplayer(function(player)
	player:set_sky({
		type = "skybox",
		textures = {
			"studtest_plainsky512_up.jpg",
			"studtest_plainsky512_dn.jpg",
			"studtest_plainsky512_rt.jpg",
			"studtest_plainsky512_lf.jpg",
			"studtest_plainsky512_ft.jpg",
			"studtest_plainsky512_bk.jpg",
		},
		clouds = false
	})
end)