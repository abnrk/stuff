functions = {}
function load_functions()
	local worldpath = minetest.get_worldpath()
	local function_files = minetest.get_dir_list(worldpath .. "/functions",false)
	for _,file in ipairs(function_files) do
		print(worldpath.."/"..file)
		local f = io.open(worldpath.."/functions/"..file,"r")
		local func = {}
		local i = 1
		for line in f:lines() do
			func[i] = line
			i = i+1
		end
		functions[file:sub(1,file:find("%.")-1)] = func
		f:close()
	end
end
load_functions()