function string:split(sep)
	local sep, fields = sep or ":", {}
	local pattern = string.format("([^%s]+)", sep)
	self:gsub(pattern, function(c) fields[#fields+1] = c end)
	return fields
end

function shallowcopy(tbl)
	local copy = {}
	for i,v in pairs(tbl) do
		copy[i] = v
	end
	return copy
end

function split_command(cmd)
	local cmd_name = nil
	local cmd_param = nil
	if cmd:find(" ") == nil then
		cmd_name = cmd
		cmd_param = ""
	else
		cmd_name = cmd:sub(1,cmd:find(" ")-1)
		cmd_param = cmd:sub(cmd:find(" ")+1)
	end
	return cmd_name,cmd_param
end

function error_handler(err)
	minetest.chat_send_all(tostring(err))
end

server_vars = {}

function load_vars()
	local worldpath = minetest.get_worldpath()
	local f = io.open(worldpath.."/vars.txt")
	local vars_serialized = f:read("*all")
	server_vars = minetest.deserialize(vars_serialized)
	f:close()
end

function execute_command(name,cmd)
	local cmd_name,cmd_params = split_command(cmd)
	local cmd_def = minetest.chatcommands[cmd_name]
	if cmd_def == nil then
		minetest.chat_send_all("Failed to execute "..tostring(cmd))
		return
	end
	cmd_def.func(name,cmd_params)
end

xpcall(load_vars,function()
	server_vars = {}
end)

local expr_env = {
	math = math,
	string = string,
}

local lua_env_vars = {}
local lua_env = {
	math = math,
	string = string,
	tostring = tostring,
	tonumber = tonumber,
	env = lua_env_vars,
	vars = server_vars,
	split_command = split_command,
	registered_nodes = minetest.registered_nodes,
	print = function(...)
		local strings = {}
		for i,v in ipairs({...}) do
			table.insert(strings,tostring(v))
		end
		minetest.chat_send_all(table.concat(strings," "))
	end,
	execute = execute_command,
}

local path = minetest.get_modpath(minetest.get_current_modname())
dofile(path .. "/functions.lua")

function save_vars()
	local worldpath = minetest.get_worldpath()
	local f = io.open(worldpath.."/vars.txt","w")
	f:write(minetest.serialize(server_vars))
	f:close()
end

minetest.register_on_shutdown(save_vars)

minetest.register_chatcommand("rem", {
	params = "",
	description = "Does nothing, therefore acting like a comment.",
	privs = {
		server = true,
	},
	func = function(name,param)
	end
})

minetest.register_chatcommand("set", {
	params = "<name> <value>",
	description = "Set CommandScript variable <name> to <value>, use /setexpr for non-string values",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local args = param:split(" ")
		local arg_name = args[1]
		local arg_value = param:sub(param:find(arg_name)+(arg_name:len()+1))
		server_vars[arg_name] = arg_value
	end
})

minetest.register_chatcommand("get", {
	params = "<name> <value>",
	description = "Get CommandScript variable <name>",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then
			return false,"Usage: /get <name>"
		end
		local arg_name = param
		minetest.chat_send_player(name,arg_name.." = "..tostring(server_vars[arg_name]))
	end
})

minetest.register_chatcommand("execute", {
	params = "<command>",
	description = "Parses <command> and executes it.\n@p is the player who executed the command\n@r is a random player on the server\n{var} would be replaced with CommandScript variable \"var\"\nExample: /execute say @p says {var} to @r",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local players = minetest.get_connected_players()
		local cmd_name,cmd_param = split_command(param)
		local cmd_def = minetest.chatcommands[cmd_name]
		if cmd_def == nil then
			return false,cmd_name .. " is not a valid command."
		end
		local replacement_character = "\27"
		local random = players[math.random(#players)]:get_player_name()
		cmd_param = cmd_param:gsub("@@",replacement_character)
		cmd_param = cmd_param:gsub("@p",name)
		cmd_param = cmd_param:gsub("@r",random)
		cmd_param = cmd_param:gsub(replacement_character,"@")
		local var_start = 0
		local var_count = select(2,cmd_param:gsub("{",""))
		local var_counter  = 0
		while true do
			var_start = string.find(cmd_param,"{",var_start+1)
			if var_start ~= nil then var_counter = var_counter+1 end
			if var_start == nil then break end
			local var_end = string.find(cmd_param,"}",var_start)
			local var = cmd_param:sub(var_start,var_end)
			cmd_param = cmd_param:gsub(var,server_vars[var:sub(2,var:len()-1)])
		end
		cmd_def.func(name,cmd_param)
	end
})

minetest.register_chatcommand("if", {
	params = "<arg1> <op> <arg2> then <command>",
	description = "Executes <command> if <arg1> <op> <arg2> is true.\n<op> can be one of the following values: ==,>,<,>=,<=\nExample: /if 1 == 1 then say true",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then
			return false,"Usage: /if <arg1> <op> <arg2> then <command>"
		end
		local args = param:split(" ")
		local arg1 = args[1]
		local op = args[2]
		local arg2 = args[3]
		local result = nil
		if op == "==" then
			result = (arg1 == arg2)
		elseif op == "~=" then
			result = (arg1 ~= arg2)
		elseif op == ">" then
			result = (arg1 > arg2)
		elseif op == "<" then
			result = (arg1 < arg2)
		elseif op == ">=" then
			result = (arg1 >= arg2)
		elseif op == "<=" then
			result = (arg1 <= arg2)
		end
		local cmd_name,cmd_param = split_command(param:sub(param:find("then")+5))
		local cmd_def = minetest.chatcommands[cmd_name]
		if cmd_def == nil then
			return false,cmd_name .. " is not a valid command."
		end
		if result == true then cmd_def.func(name,cmd_param) end
	end
})

minetest.register_chatcommand("setexpr", {
	params = "<name> <expr>",
	description = "Set CommandScript variable <name> to the result of lua expression <expr> after evaluating it.\nThe sandboxed Lua environment has access to the standard math namespace and a table named vars that contains all current CommandScript variables.",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local args = param:split(" ")
		local arg_name = args[1]
		local arg_expr = param:sub(param:find(arg_name)+(arg_name:len()+1))
		local func = loadstring("return "..arg_expr)
		local env = shallowcopy(expr_env)
		env["vars"] = minetest.settings:to_table()
		env["name"] = name
		setfenv(func,env)
		local status,result = xpcall(func,error_handler)
		if status == true then
			server_vars[arg_name] = result
		else
			return
		end
	end
})

minetest.register_chatcommand("delay", {
	params = "<time> <command>",
	description = "Execute <command> after <time> seconds",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local args = param:split(" ")
		local arg_time = args[1]
		local arg_command = param:sub(param:find(arg_time)+(arg_time:len()+1))
		local cmd_name,cmd_param = split_command(arg_command)
		local cmd_def = minetest.chatcommands[cmd_name]
		if cmd_def == nil then return false end
		minetest.after(tonumber(arg_time),cmd_def.func,name,cmd_param)
	end
})

minetest.register_chatcommand("call", {
	params = "<function>",
	description = "Call CommandScript function <function>",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local arg_name = param
		local func = functions[arg_name]
		for i,v in ipairs(func) do
			execute_command(name,v)
		end
	end
})

minetest.register_chatcommand("setnode", {
	params = "<x> <y> <z> <node>",
	description = "Sets node at position <x> <y> <z> to <node>",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local args = param:split(" ")
		local pos = {x=nil,y=nil,z=nil}
		local player = minetest.get_player_by_name(name)
		local player_pos = player:get_pos()
		local arg_x = args[1]
		local arg_y = args[2]
		local arg_z = args[3]
		if tonumber(arg_x) then pos.x = tonumber(arg_x) end
		if tonumber(arg_y) then pos.y = tonumber(arg_y) end
		if tonumber(arg_z) then pos.z = tonumber(arg_z) end
		if (arg_x == "~") then pos.x = player_pos.x end
		if (arg_y == "~") then pos.y = player_pos.y end
		if (arg_z == "~") then pos.z = player_pos.z end
		local arg_node = args[4]
		if minetest.registered_nodes[arg_node] == nil then
			return false,arg_node.." is not a registered node."
		end
		minetest.set_node(pos,{name=arg_node})
	end
})

minetest.register_chatcommand("swapnode", {
	params = "<x> <y> <z> <node>",
	description = "Swaps node at position <x> <y> <z> with <node>",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then
			return false,"Usage: /setnode <x> <y> <z> <node>"
		end
		local args = param:split(" ")
		local pos = {x=nil,y=nil,z=nil}
		local player = minetest.get_player_by_name(name)
		local player_pos = player:get_pos()
		local arg_x = args[1]
		local arg_y = args[2]
		local arg_z = args[3]
		if tonumber(arg_x) then pos.x = tonumber(arg_x) end
		if tonumber(arg_y) then pos.y = tonumber(arg_y) end
		if tonumber(arg_z) then pos.z = tonumber(arg_z) end
		if (arg_x == "~") then pos.x = player_pos.x end
		if (arg_y == "~") then pos.y = player_pos.y end
		if (arg_z == "~") then pos.z = player_pos.z end
		local arg_node = args[4]
		if minetest.registered_nodes[arg_node] == nil then
			return false,arg_node.." is not a registered node."
		end
		minetest.swap_node(pos,{name=arg_node})
	end
})

minetest.register_chatcommand("lua", {
	params = "<chunk>",
	description = "Execute lua chunk <chunk>",
	privs = {
		server = true,
	},
	func = function(name,param)
		if param == "" then return false end
		local func = loadstring(param)
		if func == nil then
			return false,"Failed to load chunk "..param
		end
		local env = shallowcopy(lua_env)
		env["name"] = name
		setfenv(func,env)
		local status,result = xpcall(func,error_handler)
	end
})