import tkinter
tcl = tkinter.Tk()
tcl.eval("source sokoban.tcl")
tcl.mainloop()