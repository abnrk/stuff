with open("levels.txt","r") as f:
  data = f.read()
lines = data.split("\n")
level = 0
filenames = []
for i,v in enumerate(lines):
  if v.startswith(";"):
    level += 1
    n = lines[i+1:]
    for x,y in enumerate(n):
      if y.startswith(";"):
        n = n[0:x]
    lvl = "\n".join(n)
    fn = "Lvls"+str(level)+".txt"
    filenames.append(fn)
    with open(fn,"wb") as f:
      f.write(bytes([ord(i) for i in list(lvl)]))
print(" ".join(filenames))