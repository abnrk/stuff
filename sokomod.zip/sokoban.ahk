#Requires AutoHotkey v2.0
#SingleInstance
#Include <Gdip>

onClose(gui) {
	ExitApp
}

initPlayfield() {
	global playfield
	playfield := []
	loop height {
		j := []
		loop width {
			j.Push(" ")
		}
		playfield.Push(j)
	}
}

loadLevel(n) {
	global px,py,boxesrequired,boxesin
	data := FileRead("levels\Lvls" . n . ".txt")
	chars := StrSplit(data)
	x := 1
	y := 1
	boxesrequired := 0
	boxesin := 0
	Gdip_GraphicsClear(g,0xffffffff)
	initPlayfield()
	for i in chars {
		if (i == Chr(10)) {
			x := 1
			y += 1
		} else {
			if (i == "@" or i == "+") {
				px := x
				py := y
			}
			if (i == ".") {
				boxesrequired += 1
			}
			if (i == "*") {
				boxesin += 1
			}
			playfield[y][x] := i
			x += 1
		}
	}
}

draw() {
	loop height {
		y := A_Index
		loop width {
			x := A_Index
			tile := playfield[y][x]
			Gdip_DrawImage(g,tilemap[tile],(x-1)*8,(y-1)*8,8,8)
		}
	}
}

move(x,y,ox,oy,collide:=false,change:="",leave:=" ") {
	tile := playfield[y][x]
	if (change == "") {
		change := tile
	}
	if (collide == true) {
		if (playfield[y+oy][x+ox] == "#" or playfield[y+oy][x+ox] == "$" or playfield[y+oy][x+ox] == "*") {
			return false
		} else {
			playfield[y][x] := leave
			playfield[y+oy][x+ox] := change
			return true
		}
	} else {
		playfield[y][x] := leave
		playfield[y+oy][x+ox] := change
		return true
	}
}

moveBox(x,y,ox,oy) {
	global boxesin
	change := ""
	leave := " "
	if (playfield[y+oy][x+ox] == ".") {
		change := "*"
	}
	if (playfield[y+oy][x+ox] == "." and playfield[y][x] == "$") {
		boxesin += 1
	}
	if (playfield[y+oy][x+ox] == " ") {
		change := "$"
	}
	if (playfield[y+oy][x+ox] == " " and playfield[y][x] == "*") {
		if (boxesin > 0) {
			boxesin -= 1
		}
	}
	if (playfield[y][x] == "*") {
		leave := "."
	}
	move(x,y,ox,oy,true,change,leave)
}

movePlayer(ox,oy) {
	global px,py
	change := ""
	leave := " "
	if (playfield[py+oy][px+ox] == ".") {
		change := "+"
	}
	if (playfield[py+oy][px+ox] == " ") {
		change := "@"
	}
	if (playfield[py][px] == "+") {
		leave := "."
	}
	if (playfield[py+oy][px+ox] == "*") {
		change := "+"
	}
	if (playfield[py+oy][px+ox] == "$") {
		change := "@"
	}
	if (playfield[py+oy][px+ox] == "$" or playfield[py+oy][px+ox] == "*") {
		moveBox(px+ox,py+oy,ox,oy)
	}
	r := move(px,py,ox,oy,true,change,leave)
	if (r == true) {
		px := px+ox
		py := py+oy
	}
}

handle(wParam,lParam,msg,hwnd) {
	global level
	if (wParam == 38) {
		movePlayer(0,-1)
	}
	if (wParam == 40) {
		movePlayer(0,1)
	}
	if (wParam == 37) {
		movePlayer(-1,0)
	}
	if (wParam == 39) {
		movePlayer(1,0)
	}
	if (wParam == 83) {
		inp := InputBox("Which level do you want to skip to?","Skip Level")
		if (inp.Result == "OK") {
			level := Number(inp.Value)
			loadLevel(level)
		}
	}
	if (wParam == 82) {
		loadLevel(level)
	}
}

width := 32
height := 24
level := 1
px := 0
py := 0
boxesrequired := 0
boxesin := 0
Gdip_Startup()
tile0 := Gdip_CreateBitmapFromFile("tiles\0.bmp")
tile1 := Gdip_CreateBitmapFromFile("tiles\1.bmp")
tile2 := Gdip_CreateBitmapFromFile("tiles\2.bmp")
tile3 := Gdip_CreateBitmapFromFile("tiles\3.bmp")
tile4 := Gdip_CreateBitmapFromFile("tiles\4.bmp")
tile5 := Gdip_CreateBitmapFromFile("tiles\5.bmp")
tile6 := Gdip_CreateBitmapFromFile("tiles\6.bmp")
tilemap := Map(" ",tile0,"@",tile1,"+",tile2,"#",tile3,"$",tile4,"*",tile5,".",tile6)
window := Gui(,"Sokoban")
window.Show("w" . (width*8)/1.5 . " h" . (height*8)/1.5)
hwnd := window.Hwnd
hbm := CreateDIBSection(width,height)
hdc := GetDC(hwnd)
obm := SelectObject(hdc,hbm)
g := Gdip_GraphicsFromHDC(hdc)
window.OnEvent("Close",onClose)
OnMessage 0x0100, handle

initPlayfield()
loadLevel(1)

loop {
	if (boxesin == boxesrequired) {
		MsgBox "Congratulations!"
		if (level < 50) {
			next := MsgBox("Next level?",,"YesNo")
			if (next == "Yes") {
				level += 1
				loadLevel(level)
			}
		} else {
			ExitApp
		}
	}
	draw()
}
