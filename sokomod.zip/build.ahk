#Requires AutoHotkey v2.0

SplitPath A_AhkPath, &fn, &dir
home := StrSplit(dir,"\")
home.Capacity -= 1
homedir := ""
for i in home {
	homedir := homedir . i . "\"
}
ahk2exe := homedir . "Compiler\Ahk2Exe.exe"
Run Chr(34) . ahk2exe . Chr(34) . " /in sokoban.ahk /out sokoban.exe /base " . Chr(34) . A_AhkPath . Chr(34) . " /icon icon.ico"