package require Tk
tk appname "Sokoban"

proc initplayfield {} {
  global width height playfield
  set playfield [lrepeat $height [lrepeat $width " "]]
}

proc loadlevel {n} {
  global playfield px py boxesrequired boxesin
  set fp [open "levels/Lvls$n.txt" r]
  set data [read $fp]
  set x 0
  set y 0
  set px 0
  set py 0
  set boxesrequired 0
  set boxesin 0
  initplayfield
  foreach i [split $data {}] {
    if {$i == "\n"} {
	  incr y
	  set x 0
	} else {
	  if {$i == "@" || $i == "+"} {
	    set px $x
		set py $y
      }
	  if {$i == "."} {
	    incr boxesrequired
      }
	  lset playfield $y $x $i
	  incr x
	}
  }
  close $fp
}

proc draw {} {
  global width height playfield tilemap
  .c delete all
  for {set y 0} {$y < $height} {incr y} {
    for {set x 0} {$x < $width} {incr x} {
      set tile [lindex $playfield $y $x]
	  .c create image [expr $x*8] [expr $y*8] -anchor nw -image $tilemap($tile)
    }
  }
}

proc move {x y ox oy {collide 0} {change 0} {leave " "}} {
  global playfield
  set tile [lindex $playfield $y $x]
  if {$change == 0} {
    set change $tile
  }
  if {$collide == 1} {
    if {[lindex $playfield [expr $y+$oy] [expr $x+$ox]] == "#" || [lindex $playfield [expr $y+$oy] [expr $x+$ox]] == "$" || [lindex $playfield [expr $y+$oy] [expr $x+$ox]] == "*"} {
      return false
    } else {
      lset playfield $y $x $leave
      lset playfield [expr $y+$oy] [expr $x+$ox] $change
      return 1
    }
  } else {
    lset playfield $y $x $leave
    lset playfield [expr $y+$oy] [expr $x+$ox] $change
    return 1
  }
}

proc movebox {x y ox oy} {
  global playfield boxesin
  set change 0
  set leave " "
  if {[lindex $playfield [expr $y+$oy] [expr $x+$ox]] == "."} {
    set change "*"
  }
  if {[lindex $playfield [expr $y+$oy] [expr $x+$ox]] == "." && [lindex $playfield $y $x] == "$"} {
    incr boxesin
  }
  if {[lindex $playfield [expr $y+$oy] [expr $x+$ox]] == " "} {
    set change "$"
  }
  if {[lindex $playfield [expr $y+$oy] [expr $x+$ox]] == " " && [lindex $playfield $y $x] == "*"} {
    if {$boxesin > 0} {
	  incr boxesin -1
	}
  }
  if {[lindex $playfield $y $x] == "*"} {
    set leave "."
  }
  move $x $y $ox $oy 1 $change $leave
}

proc moveplayer {ox oy} {
  global playfield px py
  set change 0
  set leave " "
  if {[lindex $playfield [expr $py+$oy] [expr $px+$ox]] == "."} {
    set change "+"
  }
  if {[lindex $playfield [expr $py+$oy] [expr $px+$ox]] == " "} {
    set change "@"
  }
  if {[lindex $playfield $py $px] == "+"} {
    set leave "."
  }
  if {[lindex $playfield [expr $py+$oy] [expr $px+$ox]] == "*"} {
    set change "+"
  }
  if {[lindex $playfield [expr $py+$oy] [expr $px+$ox]] == "$"} {
    set change "@"
  }
  if {[lindex $playfield [expr $py+$oy] [expr $px+$ox]] == "$" || [lindex $playfield [expr $py+$oy] [expr $px+$ox]] == "*"} {
    movebox [expr $px+$ox] [expr $py+$oy] $ox $oy
  }
  set r [move $px $py $ox $oy 1 $change $leave]
  if {$r == 1} {
    set px [expr $px+$ox]
	set py [expr $py+$oy]
  }
}

proc main {} {
  global level boxesrequired boxesin
  if {$boxesin == $boxesrequired} {
    tk_messageBox -message "Congratulations!"
	set answer [tk_messageBox -message "Next level?" -type yesno]
	if {$answer == "yes"} {
	  incr level
	  loadlevel $level
	} else {
	  exit
	}
  }
  draw
  update
  after 1 main
}

set width 32
set height 24
set canvaswidth [expr {int(($width*8)/1.2)}]
set canvasheight [expr {int(($height*8)/1.2)}]
set winwidth $canvaswidth
set winheight [expr $canvasheight+75]
set px 0
set py 0
set boxesrequired 0
set boxesin 0
set level 1
image create bitmap tile0 -file "tiles/0.xbm" -foreground black -background black
image create bitmap tile1 -file "tiles/1.xbm" -foreground yellow -background black
image create bitmap tile2 -file "tiles/2.xbm" -foreground yellow -background black
image create bitmap tile3 -file "tiles/3.xbm" -foreground red -background black
image create bitmap tile4 -file "tiles/4.xbm" -foreground black -background yellow
image create bitmap tile5 -file "tiles/5.xbm" -foreground black -background yellow
image create bitmap tile6 -file "tiles/6.xbm" -foreground cyan -background black
set "tilemap( )" tile0
set "tilemap(@)" tile1
set "tilemap(+)" tile2
set "tilemap(#)" tile3
set "tilemap($)" tile4
set "tilemap(*)" tile5
set "tilemap(.)" tile6
wm geometry . ${winwidth}x$winheight
canvas .c -background white -width $canvaswidth -height $canvasheight -borderwidth 0 -highlightthickness 0
.c create image 0 0 -anchor nw -image tile1
pack .c

bind . <Up> {moveplayer 0 -1}
bind . <Down> {moveplayer 0 1}
bind . <Left> {moveplayer -1 0}
bind . <Right> {moveplayer 1 0}
bind . <r> {loadlevel $level}

button .bup -text "\u2191" -command {moveplayer 0 -1}
button .bdown -text "\u2193" -command {moveplayer 0 1}
button .bleft -text "\u2190" -command {moveplayer -1 0}
button .bright -text "\u2192" -command {moveplayer 1 0}
pack .bup
place .bup -relx 0.42 -y 160
place .bdown -relx 0.42 -rely 0.9
place .bleft -relx 0.30 -y 186
place .bright -relx 0.55 -y 186

initplayfield
loadlevel $level
main