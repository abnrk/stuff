mem = new Uint8Array(65535);
var pc = 0;
var ra = 0;
function clamp(n,min,max) {
	return Math.min(Math.max(n,min),max);
}
function load(data,offset = 0) {
	for (var i=0; i<data.length; i++) {
		mem[i+offset] = data[i];
	}
}
function get_opcode(op) {
	var r = opcode_map[opcode]
	if (r != undefined) {
		return r;
	} else {
		return [nop,1];
	}
}
function step() {
	mem[49149] = randint(0,255);
	mem[49150] = randint(0,255);
	opcode = mem[pc];
	f = get_opcode(opcode)[0];
	len = get_opcode(opcode)[1];
	a = mem[pc+1];
	b = mem[pc+2];
	v = (a << 4) | b;
	f(opcode,v);
	if (opcode != 0) {
		console.log(opcode);
	}
	pc = clamp(pc+len,0,65535);
}
function nop() {
	// do nothing
}
function lda(op,a) {
	offset = 0
	if (op == 0x11) {
		offset = ra
	}
	if (op == 0x10 || op == 0x11) {
		ra = mem[a+offset];
	} else if (op == 0x18) {
		a = mem[a+offset];
		b = mem[a+offset+1];
		ra = (a << 4) | b;
	}
}
function sta(op,a) {
	offset = 0
	if (op == 0x11) {
		offset = ra
	}
	if (op == 0x12 || op == 0x1a) {
		ra = mem[a+offset];
	} else if (op == 0x19) {
		//16bit sta stuff
	}
}
function lda_offset(op,a) {
	ra = mem[a+ra];
}
function sta_offset(op,a) {
	mem[a+ra] = ra;
}
function and(op,a) {
	ra = mem[a]&ra;
}
function or(op,a) {
	ra = mem[a]|ra;
}
function xor(op,a) {
	ra = mem[a]^ra;
}
function shl(op,a) {
	ra = mem[a]<<ra;
}
function shr(op,a) {
	ra = mem[a]>>ra;
}
function jmp(op,a) {
	pc = a;
}
var opcode_map = {
	0x10: [lda,3], //direct
	0x11: [lda,3], //offset
	0x12: [sta,3], //direct
	0x12: [sta,3], //offset
	0x13: [and,3],
	0x14: [or,3],
	0x15: [xor,3],
	0x16: [shl,3],
	0x17: [shr,3],
	0x18: [lda,3], //16-bit direct
	0x19: [lda,3], //16-bit offset
	0x1a: [sta,3], //16-bit direct
	0x1b: [sta,3], //16-bit offset
	0x1c: [jmp,3], //16-bit offset
};
load(rom);
setInterval(step,1000/60);