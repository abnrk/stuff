import mem from "./cpu.js";

class AudioProcessor extends AudioWorkletProcessor {
	process(inputs, outputs, parameters) {
		const output = outputs[0];
		console.log(output)
		for (var c = 0; c<output.length; c++) {
		var channel = output[c];
			for (var i = 0; i<channel.length; i++) {
				channel[i] = mem[0];
			}
		}
		return true;
	}
}
registerProcessor("audioprocessor",AudioProcessor);