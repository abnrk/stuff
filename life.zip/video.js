function update() {
	for (var y=0; y<128; y++) {
		for (var x=0; x<128; x++) {
			var a = ((y*w)+x)+0xbfff;
			var c = mem[a];
			plot(x,y,c);
		}
	}
}
initCanvas(128,128);
setInterval(update,1000/60);