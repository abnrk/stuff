var a = [new Audio(),new Audio(),new Audio()];
function start() {
	for(var i=0; i<a.length; i++) {
		a[i].play();
	}
}
function check() {
	// do something
}
//setUrl();
setInterval(check,1000/60);