import queue
import time
from bitarray import bitarray

def splitWords(s):
  return s.split("\n")

class God:
  words = []
  bits = None
  def __init__(self,vocab="Vocab.DD",dbits=False):
    self.words = splitWords(open(vocab,"r").read())
    if self.words[-1] == "":
      self.words = self.words[:-1]
    binarywords = "".join(["".join([bin(ord(c)).split("0b")[1] for c in i]) for i in self.words]) + bin(int(time.time()*1000)).split("0b")[1]
    if dbits == True:
      self.bits = bitarray(binarywords,endian="little")
    else:
      self.bits = bitarray(endian="little")
  def add_bits(self,num_bits,n):
    nn = n
    b = bin(nn).split("0b")[1].zfill(num_bits)
    self.bits.pop(0)
    for i in range(num_bits):
      try:
        self.bits.append(b[i])
      except:
        self.bits.append(0)
      nn = nn >> 1
  def get_word(self):
    gotten = self.get_bits(14)%len(self.words)
    word = self.words[gotten]
    return word
  def get_bits(self,num_bits):
    n = self.bits.pop(-1)
    #result = self.bits[-num_bits:]
    #n = int(result.to01(),2)
    #self.add_bits(num_bits,n)
    result = self.bits[-num_bits:]
    result = int(result.to01(),2) << 1
    return result

if __name__ == "__main__":
  god = God("Happy.TXT",dbits=True)
  messagelength = (god.get_bits(14)%5)+4
  print(messagelength)
  print(" ".join([god.get_word() for i in range(messagelength)]))