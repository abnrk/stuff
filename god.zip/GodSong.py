from midiutil import MIDIFile
from god import God

god = God(dbits=True)
scale = ["r",59,60,62,64,65,67,69,71]
durs = [0.25,0,0.125]

def getNote():
  r = (scale[god.get_bits(32)%len(scale)],durs[god.get_bits(1)])
  return r
part1  = [getNote() for i in range(10)]
part2  = [getNote() for i in range(10)]
print(part1,part2)
degrees = part1 + part2 + part1 + part2
print(degrees)
track    = 0
channel  = 0
time     = 0    # In beats
tempo    = 60   # In BPM
volume   = 100  # 0-127, as per the MIDI standard

MyMIDI = MIDIFile(1)  # One track, defaults to format 1 (tempo track is created
                      # automatically)
MyMIDI.addTempo(track, time, tempo)

for i,v in enumerate(degrees):
  pitch, duration = v
  if not pitch == "r":
    MyMIDI.addNote(track, channel, pitch, time, duration, volume)
  time = time+duration

with open("output.mid", "wb") as output_file:
  MyMIDI.writeFile(output_file)