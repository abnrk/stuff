from flask import Flask,render_template,request,abort,Response,redirect,jsonify,send_from_directory,url_for
import os
import glob
app = Flask(__name__,static_url_path="",static_folder="static")

@app.route('/')
def index():
    return app.send_static_file("index.html")

@app.route('/getfiles')
def getfiles():
    path = request.args.get("path")
    path = path.replace("..","/")
    path = os.path.normpath(path)
    path = path.replace("\\","/")
    r = {"files": glob.glob("./"+path)[1:]}
    return jsonify(r)

port = 80
app.run(host="0.0.0.0",port=port)