import glob
import os
import json
def getType(path):
    r = -1
    if os.path.isdir(path):
        r = 0
    if os.path.isfile(path):
        r = 1
    return r
files = [i.replace(os.sep,"/") for i in glob.glob("**",recursive=True) if (i != "genfiles.py") and (i != "index.html") and (i != "files.json")]
filesjson = {"/": 0}
for i in files:
    filesjson["/"+i] = getType(i)
with open("files.json","w") as f:
    f.write(json.dumps(filesjson))