Place your files in here and they stay here!
This drive uses your browser's local storage to store your precious files.