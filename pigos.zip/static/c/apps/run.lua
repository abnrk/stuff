local w = createWindow(
	"Run",
	[[
	<textarea id="appname" name="appname" rows="1" cols="24"></textarea>
	<button id="runbtn" class="sys48_button">Run</button>
	]],
	210,
	100,
	false
)
local win = document:getElementById("sys48_window_"..w)
function runButton()
	local appname = win:querySelector("#appname").value
	runApp(appname)
end
win:querySelector("#runbtn"):addEventListener("click",runButton)