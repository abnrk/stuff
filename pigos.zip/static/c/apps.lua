registerApp("run","/c/apps/run.lua")
registerApp("hello","/c/apps/hello.lua")