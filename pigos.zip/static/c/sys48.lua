js = require("js")
window = js.global
document = window.document
body = document:getElementById("sys48_body")
start = document:getElementById("sys48_start")
windows = {}
apps = {}
_args = {}
anim_in = {"bounceIn","bounceInDown","bounceInLeft","bounceInRight","bounceInUp","flip","lightSpeedInRight","lightSpeedInLeft","rotateIn","rotateInDownLeft","rotateInUpLeft","zoomIn","zoomInDown","zoomInLeft","zoomInRight"}
anim_out = {"bounceOut","bounceOutDown","bounceOutLeft","bounceOutRight","bounceOutUp","flipOutX","lightSpeedOutRight","lightSpeedOutLeft","rotateOut","rotateOutDownLeft","rotateOutUpLeft","hinge","zoomOutDown","zoomOutLeft","zoomOutRight"}
anim_misc = {"bounce","rubberBand","swing","tada","wobble","jello"}
function sleep(n)
	local t = os.clock()
	while os.clock() - t <= n do
		-- nothing
	end
end
function closeButton(x)
	local split = {}
	local i = 1
	for w in string.gmatch(x.parentElement.parentElement.id,"[^_]+") do
		split[i] = w
		i = i + 1
    end
	destroyWindow(split[3])
end
function createWindow(title,html,width,height,resizable)
	if (resizable == nil) then
		resizable = true
	end
	local wid = ""
	for i=1,16 do
		wid = wid..string.format("%x",math.random(0xf))
	end
	local w = document:createElement("div")
	w:setAttribute("id","sys48_window_"..wid)
	local class = "sys48_button sys48_window"
	if (resizable == true) then
		class = "sys48_button sys48_window_resizable"
	end
	class = class.." animate__"..anim_in[math.random(1,#anim_in)]
	w:setAttribute("class",class)
	w:setAttribute("style","width:"..width.."px;height:"..height.."px;position:absolute;left:"..math.random(100).."%;top:"..math.random(100).."%;")
	local titlebar = document:createElement("div")
	local span = document:createElement("span")
	local text = document:createTextNode(title)
	local closebtn = document:createElement("button")
	titlebar:setAttribute("id","sys48_window_"..wid.."_title")
	titlebar:setAttribute("class","sys48_window_titlebar")
	titlebar:setAttribute("style","height:16px")
	closebtn:setAttribute("id","sys48_window_"..wid.."_close")
	closebtn:setAttribute("class","sys48_button")
	closebtn:setAttribute("style","float:right")
	closebtn:addEventListener("click",closeButton)
	closebtn.innerHTML = "X"
	titlebar:appendChild(closebtn)
	span:setAttribute("style","font-family:sans-serif;font-size:12px;color:white;")
	span:appendChild(text)
	titlebar:appendChild(span)
	w:appendChild(titlebar)
	local main = document:createElement("div")
	main:setAttribute("id","sys48_window_"..wid.."_main")
	main:setAttribute("class","sys48_window_main")
	main.innerHTML = html
	w:appendChild(main)
	body:appendChild(w)
	windows[wid] = w
	return wid
end
function destroyWindow(id)
	windows[id]:remove()
	windows[id] = nil
end
function registerApp(name,run,icon)
	apps[name] = {name,run,icon}
end
function runApp(name,args)
	window.user48()
	dofile(apps[name][2])
end
function startButton()
	runApp("run")
end
dofile("/c/apps.lua")
start:addEventListener("click",startButton)