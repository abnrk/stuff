js = require("js")
window = js.global