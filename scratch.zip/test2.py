from scratchclient import ScratchSession

session = ScratchSession("BlorpusYeeter", "readbook1")

# post comments
session.get_user("BlorpusYeeter").post_comment("My")