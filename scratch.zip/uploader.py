import scratch
import markovify
import json
import shutil
from scratchclient import ScratchSession, Studio
from PIL import Image, ImageDraw

brain = "corpus.txt"
username = "BlorpusYeeter"
password = "readbook1"
session = ScratchSession(username, password)

with open(brain) as f:
    text = f.read()

text_model = markovify.Text(text)
    
with open("template.json","r") as f:
  template = f.read()

title = str(text_model.make_short_sentence(80))
speak = str(text_model.make_short_sentence(280))
img = Image.new("RGB", (100, 30), color = (73, 109, 137))
 
d = ImageDraw.Draw(img)
d.text((10,10), "Hello World", fill=(255,255,0))
 
img.save("preview.gif")
with open("preview.gif","rb") as f:
  preview = f.read()

newJson = template.replace("TEXTGOESHERE",speak.replace("\"",'\\"').replace("\n","\\n").replace("{","\\{").replace("}","\\}"))
with open("project/project.json","w") as f:
  f.write(newJson)
shutil.make_archive("project", "zip", "project")
with open("project.zip","rb") as f:
  project = f.read()
r = scratch.upload(username,password,title,"",project,preview)
#session.get_user("BlorpusYeeter").get_projects()[0].share()