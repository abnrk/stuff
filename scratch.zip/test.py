import scratch

with open("Gumi.sb3", "rb") as f:
  project = f.read()
with open("test.gif", "rb") as f:
  preview = f.read()

username = "BlorpusYeeter"
password = "readbook1"

r = scratch.upload(username,password,"Coot Songied","",project,preview)
print(r.text)