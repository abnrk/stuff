import requests
from bs4 import BeautifulSoup

def upload(username,password,project_name="Untitled Project",project_description="",binary_file=None,preview_image=None):
  data = {"username": username, "password": password, "scratchkey": "ch4ng3me", "project_name": project_name, "project_description": project_description}
  files = {"binary_file": (project_name, binary_file, "application/octet-stream"), "preview_image": (project_name, preview_image, "image/gif")}
  r = requests.post("https://scratch.mit.edu/services/upload", data=data, files=files)
  return r

def replyCheck(str):
  if str.startswith("@"):
   return str
  else:
    return str[1:len(str)]

def getComments(user):
  r = requests.get(f"https://scratch.mit.edu/site-api/comments/user/{user}/")
  soup = BeautifulSoup(r.text, 'html.parser')
  comments = soup.find_all("div", class_="comment")
  return [(replyCheck(i.find("div", class_="content").text.replace("\n", "").replace("                    ", " ").replace("          ", "")), int(i["data-comment-id"])) for i in comments]
  #return r.text