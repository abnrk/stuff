from scratchclient import ScratchSession, Studio
import scratch
import markovify
import requests
mode = 1
min = 0
max = 9000
max = max + min
username = "BlorpusYeeter"
password = "readbook1"
session = ScratchSession(username, password)
profile = session.get_user("BlorpusYeeter")
comments = scratch.getComments("BlorpusYeeter")
latestcomment = comments[0][1]
print("Latest comment id:", latestcomment)
with open("scratchcorpus.txt", "a+") as f:
  corpus = f.read()
  for i in comments:
    if not i[0] in corpus:
      print("Comment", i[1], "not in corpus! Adding...")
      f.write(i[0] + "\n")
    else:
      pass
#corpus = '\n'.join([i[0] for i in comments])
with open("scratchcorpus.txt", "r", encoding="utf-8") as f:
  #f.write(corpus)
  corpus = f.read()

markov = markovify.Text(corpus, state_size=1)
newComment = markov.make_short_sentence(80)

print("New comment:", newComment)
profile.post_comment(str(newComment), parent_id=str(latestcomment))